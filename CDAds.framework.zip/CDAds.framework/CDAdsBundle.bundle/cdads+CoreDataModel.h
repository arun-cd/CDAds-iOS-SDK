//
//  cdads+CoreDataModel.h
//  
//
//  Created by Arun Gupta on 05/03/19.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

#import "PendingLocations+CoreDataClass.h"




