//
//  PendingLocations+CoreDataClass.m
//  
//
//  Created by Arun Gupta on 05/03/19.
//
//  This file was automatically generated and should not be edited.
//

#import "PendingLocations+CoreDataClass.h"

@implementation PendingLocations

@end
