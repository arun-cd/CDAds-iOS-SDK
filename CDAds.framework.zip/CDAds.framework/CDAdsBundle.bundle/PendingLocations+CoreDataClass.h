//
//  PendingLocations+CoreDataClass.h
//  
//
//  Created by Arun Gupta on 05/03/19.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface PendingLocations : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "PendingLocations+CoreDataProperties.h"
