//
//  CDADRequestError.h
//  Pods
//
//  Created by Arun Gupta on 12/01/19.
//
//

#import <Foundation/Foundation.h>

@interface CDADRequestError : NSError

-(NSString*)getCDADdescription;

@end
